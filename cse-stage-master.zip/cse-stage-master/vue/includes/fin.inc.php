                    </center>                    
                </td>
            </tr>
        </table>

        
        <?php
        echo \controleur\GestionErreurs::printErreurs();
        \controleur\GestionErreurs::razErreurs();
        ?>
    </body>
</html>

