<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Sites Test</title>
    </head>
    <body>
        <?php
        use modele\metier\Site;
        require_once __DIR__ . '/../../includes/autoload.inc.php';
        echo "<h2>Test unitaire de la classe métier Site</h2>";
        
        $objet =  $unSite = new Site("01", "Baugerie");
        var_dump($objet);
        ?>
    </body>
</html>