<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Email Test</title>
    </head>
    <body>
        <?php
        use modele\metier\Email;
        require_once __DIR__ . '/../../includes/autoload.inc.php';
        echo "<h2>Test unitaire de la classe métier Email</h2>";
        
        $objet =  $unEmail = new Email("01", "laubert@la-joliverie.com");
        var_dump($objet);
        ?>
    </body>
</html>